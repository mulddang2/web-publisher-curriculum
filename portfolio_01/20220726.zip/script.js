$( document ).ready( function() {
    $( '.gallery_all' ).slick( {
      slidesToShow: 3,
      //autoplay: true,
      autoplaySpeed: 1500,
      centerMode: true,
      centerPadding: "300px",
    } );
  } );