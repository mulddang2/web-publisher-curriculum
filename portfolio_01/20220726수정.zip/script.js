$( document ).ready( function() {
    $( '.gallery_all' ).slick( {
      slidesToShow: 3,
      autoplay: true,
      autoplaySpeed: 1500,
      centerMode: true,
      centerPadding: "100px",
      infinite: true,
      arrows : true,
    } );
  } );
$( document ).ready( function() {
    $( '.video_all' ).slick( {
      slidesToShow: 3,
      //autoplay: true,
      autoplaySpeed: 1500,
      centerMode: true,
      centerPadding: "100px",

    } );
  } );